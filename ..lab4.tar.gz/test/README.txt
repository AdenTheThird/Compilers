Tests:

test1

The minimal valid program. You'll need program, block, and print, plus some 
level of statement handling to process a single statement.

test2

Adds multiple statements (only the print statement is implemented, but more than
one of them).

test3

Adds expression handling to test2

test4

Initialized symbol table, variable declarations, and variable references.

test5a: if
test5b: adds 'else' to if
test5c: adds while
test5d: adds blocks to if and while
test5e: adds nesting to if and while
test5f: adds return and assignments

test6

Adds nested blocks, including nested symbol tables

test7

Adds struct definitions, variables, and references

test8

Adds function declarations, definitions, and calls

test9

Operator precedence and associativity

test10

Adds array definitions and references

test11

tests prints() and strng literals
